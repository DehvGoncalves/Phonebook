﻿namespace ControleDeContatos.Models {

    //Noosa tabela Contato no banco de dados terá essas 4 colunas
    public class ContatoModel {
        public int Id { get; set; } //Vai representar o id do contato, chave primária auto incrementada
        public string Nome { get; set; } //Vai representar o nome do contato
        public string Email { get; set; } //Vai representar o email do contato
        public string Celular { get; set; } //Vai representar o telefone do contato
    }
}
