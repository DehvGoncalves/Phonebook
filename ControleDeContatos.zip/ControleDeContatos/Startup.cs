﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using ControleDeContatos.Models;
using ControleDeContatos.Data;

namespace ControleDeContatos {
    public class Startup {

    public Startup(IConfiguration configuration) {
            configuration = configuration;
        }
        public IConfiguration configuration { get; }

        public void ConfigureServices(IServiceCollection services) {
            services.AddControllersWithViews();
            services.AddEntityFrameworkSqlServer() //Estamos falando: Vou usar o SQLServer e o contexto que vou mandar é esse BancoContext, que vai todas as tabelas dentro desse banco context. 
                .AddDbContext<BancoContext>(); //Extensão que baixamos

        }
     
                public void Configure(IApplicationBuilder app, IWebHostEnvironment env) {
            if (env.IsDevelopment()) {
                app.UseDeveloperExceptionPage();
            }
            else {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints => {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
