﻿using ControleDeContatos.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControleDeContatos.Data {
    public class BancoContext : DbContext {

        //VAMOS CRIAR O CONSTRUTOR E INJETAR COMO PARÂMETRO DE ENTRADA O DbContextOptions e Dentro do DbContextOptions vamos tipar ele como BancoContext que é a própria classe que estamos criando

        //aqui pode dar o nome de options mesmo pra essa nossa injeção, basicamente como estamos injetando esse cara,
        //vamos passar essa injeção de options pra dentro do construtor padrão.
        public BancoContext (DbContextOptions<BancoContext> options) : base(options) { }

        //O primeiro contecto de tabela, vamos informar a classe que representa a tabela do banco de dados: ContatoModel + Nome que vamos dar pra tabela.
        //Com isso a configuração do contexto está configurada
        public DbSet<ContatoModel> Contatos { get; set; }
    }
}
