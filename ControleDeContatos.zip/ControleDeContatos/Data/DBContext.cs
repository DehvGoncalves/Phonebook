﻿namespace ControleDeContatos.Data {
    public class DBContext {
    }
}